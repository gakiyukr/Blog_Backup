<?php

  global $config;
  $config = [];

  // 程序安装路径
  $config['path'] = '/';
  // ID 长度
  $config['length'] = 4;
  // 网站标题
  $config['title'] = 'CRZ.im';
  // 网站简介
  $config['description'] = '某千岁的网址缩短服务';

?>